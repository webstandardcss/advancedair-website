
<footer class="footer container">
<!-- Footer Starts -->

	<article class="col-md-2 col-sm-4 text-center">
    <div class="row">
    <!-- Each Column Starts -->
    
    	<h3>Service Centers</h3>
    	<p>Henderson, TX<br />
        907 Milord Dr.<br />
        (903)667-1961</p>
        
    <!-- Each Column Ends -->
    </div>
    </article>

	<article class="col-md-2 col-sm-4 text-center">
    <div class="row">
    <!-- Each Column Starts -->
    
    	<h3>Regional Sales</h3>

        <p>Longbeach, CA<br />
        Napolean, OH</p>
    
    <!-- Each Column Ends -->
    </div>
    </article>

	<article class="col-md-2 col-sm-4 text-center hide-responsive2">
    <div class="row">
    <!-- Each Column Starts -->
    	<h3></h3>
    <!-- Each Column Ends -->
    </div>
    </article>

	<article class="col-md-2 col-sm-4 text-center hide-responsive">
    <div class="row">
    <!-- Each Column Starts -->
    	<h3></h3>
    <!-- Each Column Ends -->
    </div>
    </article>

	<article class="col-md-2 col-sm-4 text-center hide-responsive">
    <div class="row">
    <!-- Each Column Starts -->
    	<h3></h3>
    <!-- Each Column Ends -->
    </div>
    </article>

	<article class="col-md-2 col-sm-4 text-center hide-responsive">
    <div class="row">
    <!-- Each Column Starts -->
    	<h3></h3>
    <!-- Each Column Ends -->
    </div>
    </article>
    
    <div class="clearfix"></div>
    
    <p class="p-bottom">This site is property of Advanced Air Technologies. Use of material without written consent is expressly prohibited. Site designed and maintained by <a href="http://rkvideo.tv">RK Productions</a></p>

<!-- Footer Ends -->
</footer>

</body>
</html>