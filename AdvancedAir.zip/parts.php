<?php include_once('header.php'); ?>

<section class="main-content container">
<div class="col-sm-12">
<!-- Main Contents Starts -->

<h1>Parts</h1>
<h2>Advanced Air Technologies is the choice for all your parts needs.</h2>
<p>Our staff is dedicated to providing our customers with cost effective and quality guaranteed parts for all major brands. Click on the link below to start your parts order.</p>
<br /><br />
<div>
<center>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="320" height="240">
    <param name="movie" value="flash/parts.swf">
    <param name="quality" value="high">
    <param name="loop" value="true">
    <param name="flashvars" value="videofile=parts.flv" />
    <embed src="flash/parts.swf" flashvars="videofile=parts.flv" quality="high" loop="true" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="320" height="240"></embed>
</object>
</center>
<!--
<img src="images/parts/6.jpg" />
<p class="bold image_caption">AAT has Maufacturer Replacements & Aftermarket Parts and Lubricants</p>

<img src="images/parts/2.jpg" />
<p class="bold image_caption">Sullivan-Palatek OEM Parts</p>

<img src="images/parts/3.jpg" />
<p class="bold image_caption">Ingersoll-Rand OEM Parts</p>

<img src="images/parts/4.jpg" />
<p class="bold image_caption">New & Remanufactred Centrifugal Compressor Parts</p>

<img src="images/parts/5.jpg" />
<p class="bold image_caption">Sullair OEM Parts</p>

<img src="images/parts/1.jpg" />
<p class="bold image_caption">Quincy OEM Parts</p>
-->

<br /><br />
<h2><a href="customer_new.php">Click here to order parts!</a></h2>

</div>


    
    <br /><br /><br />
    
    <article class="col-sm-5 video text-center">
        <iframe width="420" height="315" src="https://www.youtube.com/embed/XQu8TTBmGhA" frameborder="0" allowfullscreen></iframe>
    </article>
    
    <article class="col-sm-5 image col-sm-offset-2 text-center">
    	<img src="images/img.png" alt="" class="img-responsive" />
    </article>

<!-- Main Contents Ends -->
</div>
</section>


<?php include_once('footer.php'); ?>
