<?php include_once('header.php'); ?>

<section class="main-content container">
<div class="col-sm-12">
<!-- Main Contents Starts -->

	<section class="contents col-sm-8">
    <!-- Contents Starts -->
    
        <h1>Page Title</h1>
        <h2>Content</h2>
        
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean id imperdiet nibh. Curabitur scelerisque ut tortor quis laoreet. Etiam ac urna egestas, auctor nibh vitae, scelerisque ligula. Etiam id rhoncus odio, at semper orci. In eleifend augue ante, vitae lacinia nunc convallis in. Sed neque ante, consectetur quis dui eget, feugiat aliquam lectus. Maecenas in nibh mi. Nam fringilla arcu nec nisi placerat maximus. Donec a blandit mauris. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
        <p>Nunc orci ante, dignissim quis tellus imperdiet, tincidunt faucibus lorem. Aliquam fermentum tincidunt sapien ut rhoncus. Vestibulum sed lacinia erat. Aliquam malesuada leo ac est consequat, non iaculis dolor dictum. Ut eget interdum diam. Morbi dui turpis, interdum sit amet enim eu, consequat elementum urna. Quisque sapien lorem, tempor eu massa non, faucibus iaculis lectus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla eu arcu massa. Aliquam sed tortor a nulla aliquam interdum. Aenean auctor gravida quam, at ultrices quam scelerisque in.</p>
        <p>Fusce accumsan est id ultrices rhoncus. Duis fringilla gravida rutrum. Fusce mauris nisl, volutpat in libero ut, interdum varius tortor. Nam consequat dui et arcu condimentum, consequat varius libero facilisis. Nam sit amet augue ut nisl gravida facilisis. Integer ultrices est vel varius ultricies. Donec congue, orci id aliquet iaculis, massa lectus vulputate dolor, eget auctor metus est ac eros. Fusce nec mollis enim. Suspendisse placerat tempus odio vitae gravida. Aenean mattis felis turpis. Phasellus facilisis condimentum leo ultrices lacinia. Nullam augue nulla, vestibulum eu facilisis ut, tempus a nulla. Curabitur finibus commodo mattis. Donec iaculis neque a enim imperdiet, ut convallis lacus rutrum.</p>
        
        <br /><br /><br />
        
        <article class="col-sm-6 image text-center">
            <img src="images/img.png" alt="" class="img-responsive" />
        </article>
        
        <article class="col-sm-6 video text-center">
            <iframe width="420" height="315" src="https://www.youtube.com/embed/XQu8TTBmGhA" frameborder="0" allowfullscreen></iframe>
        </article>
        
    <!-- Contents Ends -->
    </section>
    
    <aside class="col-sm-4">
    <!-- Aside Starts -->
    	<br /><br />
        <img src="images/img2.png" alt="" class="s-img" />
        
    <!-- Aside Ends -->
    </aside>
	

<!-- Main Contents Ends -->
</div>
</section>


<?php include_once('footer.php'); ?>
